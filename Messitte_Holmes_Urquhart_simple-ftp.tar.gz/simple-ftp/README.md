# simple-ftp project
Josh Messitte, Alex Holmes, Robert

## Current State:
- Server works in linux environment.

## Outstanding Issues:
- Clean up print statements?

### Compile Client:
```
$ javac myftp.java
```
### Compile Server:
```
$ javac myftpserver.java
```

### Run Client:
```
$ java myftp [MACHINE_NAME] [PORT]
```

### Run Server:
```
$ java myftpserver [PORT]
```

This project was done in its entirety by Josh, Alex, and Robert. We hereby
state that we have not received unauthorized help of any form. 
